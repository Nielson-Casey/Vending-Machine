import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {
	
	public static void main(String[] args) {
        // TODO Auto-generated method stub
        Main aSillyHibernateUseExample = new Main();   
        Employee e1 = new Employee();
        e1.setFirstName("John");
        e1.setLastName("Smith");
        e1.setSalary(200);
       
        aSillyHibernateUseExample.addNewUsers(e1);
	}

	private void addNewUsers(Employee employee) {
		 Session session = HibernateUtilSingleton.getSessionFactory().getCurrentSession();
	        /*
	         * all database interactions in Hibernate are required to be inside a transaction.
	         */
	        Transaction transaction = session.beginTransaction();	           
	        /*
	         * save each instance as a record in the database
	         */
	        session.save(employee);	        
	        transaction.commit();
	        /*
	         * prove that the User instances were added to the database and that
	         * the instances were each updated with a database generated id.
	         */
	        System.out.println("An Employee generated ID is: " + employee.getId());
	        
		
	}

}
